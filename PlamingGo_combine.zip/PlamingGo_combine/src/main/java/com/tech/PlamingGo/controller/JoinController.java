package com.tech.PlamingGo.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tech.PlamingGo.dao.JoinDaoImpl;
import com.tech.PlamingGo.dto.JoinDto;

@Controller
public class JoinController {
	
	//SqlSession
	//@AutoWired : 각 상황에 타입에 맞는 loC컨테이너 안에 존재하는 Bean 자동 주입
	@Autowired
	private SqlSession sqlSession;
	
	
	@RequestMapping("/reg")
	public String reg(Model model, HttpServletRequest request) {
		String user_id = request.getParameter("user_id");
		String user_pw = request.getParameter("user_pw");
		String user_email = request.getParameter("user_email");
		String user_name = request.getParameter("user_name");
		String user_birth = request.getParameter("user_birth");
		String user_phone = request.getParameter("user_phone");
		int user_gender=Integer.parseInt(request.getParameter("user_gender"));
	
		
		JoinDaoImpl joindao = sqlSession.getMapper(JoinDaoImpl.class);
		JoinDto joindto = joindao.reg(user_id, user_pw, user_email, user_name, user_birth, user_gender, user_phone);
		
		return "home";
		
		

	}
	
	
//	@RequestMapping("/reg")
//	public String reg(Model model, HttpServletRequest request){
//		String user_id = request.getParameter("user_id");
//		String user_pw = request.getParameter("user_pw");
//		String user_email = request.getParameter("user_email");
//		String user_name = request.getParameter("user_name");
//		String user_birth = request.getParameter("user_birth");
//		String user_phone = request.getParameter("user_phone");
//		String user_g=request.getParameter("user_gender");
//		int user_gender = Integer.parseInt(user_g);
//		
//		
//		
//		//JoinDao.java로 접속
//		JoinDao joindao=sqlSession.getMapper(JoinDao.class);
//		System.out.println("joindao.java 접속성공");
//		//JoinDto타입의 joindto라는변수안에 joindao의 reg를 담는다.
//		
//		joindao.reg(user_id, user_pw, user_email, user_name, user_birth, user_gender, user_phone);
//		
//
//		return "redirect:login";
//		
//	}
	
	

}
