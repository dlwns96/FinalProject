package com.tech.PlamingGo.dao;

public class BoardDao {

}
